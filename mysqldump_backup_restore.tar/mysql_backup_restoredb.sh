#!/bin/bash

# Usage: ./mysql_backup_restoredb.sh schema_name.hostname.domain.DD-MM-YYYY_HHMM > restoredb.sh

#DIR=/mnt/backup/db-backup
#BACKUPFILE=$1
#DBNAME=echo $BACKUPFILE |  cut -d . -f 1

# BACKUPFILE="USER INPUT"
read -p "Enter the BACKUPFILE being used:                   " BACKUPFILE
# filedir="USER INPUT"
read -p "Now enter the directory where $BACKUPFILE resides: " filedir
# MySQL Router instance
# mysqlrouter="USER INPUT"
read -p "Now provide the MySQL Router hostname to be used:  " mysqlrouter
echo 
echo "You have entered: $BACKUPFILE $filedir & $mysqlrouter:"
echo 
read -p "Continue? (Y/N): " confirm && [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]] || exit 1


cd $filedir
for i in `echo $BACKUPFILE | cut -d . -f 1`; do echo "select \"""$i"\""; drop database $i; create database $i; use $i; source "`ls $BACKUPFILE`"; select count(table_name) from information_schema.tables where table_schema = '$i';" > restore_cre_db_$i.sql ; echo "mysqlsh icadmin@$mysqlrouter --log-file=restore_cre_db_$i.log --sqlc -e \"source restore_cre_db_$i.sql;\""; echo "grep -i 'create table' `ls $BACKUPFILE`  | wc -l"; done > restoredb.sh


echo 
echo "Now run 'cd $filedir' and execute 'restoredb.sh'"
echo 
