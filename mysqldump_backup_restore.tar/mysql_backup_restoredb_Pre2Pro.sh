#!/bin/bash

# Usage: ./mysql_backup_restoredb_Pre2Pro.sh
# mysqlump file has format: db_name.hostname.domain.DD-MM-YYYY_HHMM

# BACKUPFILE="USER INPUT"
read -p "Enter the BACKUPFILE being used:                   " BACKUPFILE
# filedir="USER INPUT"
read -p "Now enter the directory where $BACKUPFILE resides: " filedir
# MySQL Router instance
# mysqlrouter="USER INPUT"
read -p "Now provide the MySQL Router hostname to be used:  " mysqlrouter
# New DB name
# NEWDBNAME="USER INPUT"
read -p "Enter the target / new database schema name:       " NEWDBNAME
echo 
echo "You have entered: "
echo "                  "$BACKUPFILE
echo "                  "$filedir
echo "                  "$mysqlrouter
echo "                  "$NEWDBNAME
echo 
read -p "Continue? (Y/N): " confirm && [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]] || exit 1


cd $filedir
for i in `echo $BACKUPFILE | cut -d . -f 1`; do echo "select \"""$i"\""; drop database $NEWDBNAME; create database $NEWDBNAME; use $NEWDBNAME; source "`ls $BACKUPFILE`"; select count(table_name) from information_schema.tables where table_schema = '$i' or table_schema = '$NEWDBNAME';" > restore_cre_db_$NEWDBNAME.sql ; echo "mysqlsh icadmin@$mysqlrouter --log-file=restore_cre_db_$NEWDBNAME.log --sqlc -e \"source restore_cre_db_$NEWDBNAME.sql;\""; echo "grep -i 'create table' `ls $BACKUPFILE`  | wc -l"; done > restoredb_$NEWDBNAME.sh


echo 
echo "Now run 'cd $filedir' and execute 'restoredb_$NEWDBNAME.sh'"
echo 
