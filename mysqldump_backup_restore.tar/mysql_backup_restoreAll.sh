#!/bin/bash

# Usage: ./mysql_backup_restoreAll.sh
# mysqlump file has format: db_name.hostname.domain.DD-MM-YYYY_HHMM


# filedir="USER INPUT"
read -p "Now enter the directory where all the backupfiles resides: " filedir
# MySQL Router instance
# mysqlrouter="USER INPUT"
read -p "Now provide the MySQL Router hostname to be used:  " mysqlrouter
echo 
echo "You have entered: $filedir & $mysqlrouter:"
echo 
read -p "Continue? (Y/N): " confirm && [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]] || exit 1


#BACKUPFILE=`ls $filedir| grep 00 | grep 2024_ | grep -v mysql `
#DBNAME=echo $BACKUPFILE |  cut -d . -f 1

cd $filedir

for i in `ls | grep -v mysql | grep 00 | grep 2024_ | cut -d . -f 1`; do echo "select \"""$i"\""; drop database $i; create database $i; use $i; source "`ls $i*`"; select count(table_name) from information_schema.tables where table_schema = '$i';" > cre_db_$i.sql ; echo "mysqlsh icadmin@$mysqlrouter --log-file=cre_db_$i.log --sqlc -e \"source cre_db_$i.sql;\""; echo "grep -i 'create table' `ls $i*`  | wc -l"; done > restoreAll.sh


chmod 744 $filedir/restoreAll.sh
echo 
echo "Now run 'cd $filedir' and execute './restoreAll.sh > restoreAll.sh.log '"
echo 
